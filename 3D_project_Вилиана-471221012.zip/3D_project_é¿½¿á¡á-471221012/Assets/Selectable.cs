using UnityEngine;
public class Selectable : MonoBehaviour
{
    public Vector3 viewPos;
}